package model;

public enum Cor {  // mudado para public
    BRANCO, PRETO;
}
