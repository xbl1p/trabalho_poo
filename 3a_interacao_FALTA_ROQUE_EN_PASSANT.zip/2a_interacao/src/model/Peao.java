package model;

public class Peao extends Peca {
    private boolean primeiroMovimento = true;
    private boolean acabouDeFazerMovimentoDuplo = false;
    private static Peao ultimoPeaoMovido = null;

    public Peao(Cor cor, int linha, int coluna) {
        super(cor, linha, coluna);
    }

    // Métodos getter/setter para primeiroMovimento
    public boolean isPrimeiroMovimento() {
        return primeiroMovimento;
    }

    public void setPrimeiroMovimento(boolean primeiroMovimento) {
        this.primeiroMovimento = primeiroMovimento;
    }

    @Override
    public boolean podeMoverPara(Tabuleiro tabuleiro, int l, int c) {
        if (l < 0 || l > 7 || c < 0 || c > 7) return false; 

        int direcao = (getCor() == Cor.BRANCO) ? -1 : 1;
        boolean casaLivre = tabuleiro.getPeca(l, c) == null;

        // Movimento para frente
        if (c == getColuna() && casaLivre) {
            // Movimento simples
            if (l == getLinha() + direcao) {
                System.out.println("[DEBUG Peao] Movimento simples permitido");
                return true;
            }
            
            // Movimento duplo inicial (condição simplificada)
            if (isPrimeiroMovimento() && 
                l == getLinha() + 2 * direcao && 
                tabuleiro.getPeca(getLinha() + direcao, c) == null) {
                System.out.println("[DEBUG Peao] Movimento duplo permitido - primeiro movimento: " + isPrimeiroMovimento());
                return true;
            }
        }

        // Captura diagonal normal
        if (Math.abs(c - getColuna()) == 1 && l == getLinha() + direcao) {
            Peca oponente = tabuleiro.getPeca(l, c);
            if (oponente != null && oponente.getCor() != getCor()) {
                System.out.println("[DEBUG Peao] Captura diagonal permitida");
                return true;
            }
            
            // Verificar en passant
            if (casaLivre && MovimentoEspecial.podeEnPassant(tabuleiro, this, c)) {
                System.out.println("[DEBUG Peao] En passant permitido");
                return true;
            }
        }

        return false;
    }
    
    @Override
    public void setPosicao(int linha, int coluna) {
        // Resetar flag de movimento duplo para todos os peões
        if (ultimoPeaoMovido != null) {
            ultimoPeaoMovido.acabouDeFazerMovimentoDuplo = false;
        }
        
        // Verificar se foi movimento duplo
        int diferencaLinhas = Math.abs(linha - getLinha());
        if (isPrimeiroMovimento() && diferencaLinhas == 2) {
            acabouDeFazerMovimentoDuplo = true;
            ultimoPeaoMovido = this;
        }
        
        super.setPosicao(linha, coluna);
        setPrimeiroMovimento(false);
    }
    
    public boolean acabouDeFazerMovimentoDuplo() {
        return acabouDeFazerMovimentoDuplo;
    }
    
    public static void resetarEnPassant() {
        if (ultimoPeaoMovido != null) {
            ultimoPeaoMovido.acabouDeFazerMovimentoDuplo = false;
            ultimoPeaoMovido = null;
        }
    }
}