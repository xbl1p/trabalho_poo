/**
 * 
 */
/**
 * 
 */
module xadrez_2a_interacao {
    requires java.desktop;
}