package view;

import util.ObservadorIF;
import util.ObservadoIF;
import javax.swing.JOptionPane;

/**
 * Fachada da View - não herda de nenhuma classe Swing
 * Responsável por receber solicitações do Model ou Controller
 * que resultem em alterações na GUI
 */
public class FachadaView implements ObservadorIF {
    private JanelaPrincipal janelaPrincipal;
    private TabuleiroGrafico tabuleiroGrafico;
    
    public FachadaView(JanelaPrincipal janela) {
        this.janelaPrincipal = janela;
    }
    
    public void setTabuleiroGrafico(TabuleiroGrafico tabuleiro) {
        this.tabuleiroGrafico = tabuleiro;
    }
    
    /**
     * Implementação do método notify do padrão Observer
     * Atualiza a interface gráfica quando o modelo muda
     */
    @Override
    public void notify(ObservadoIF o) {
        System.out.println("[DEBUG FachadaView] Recebeu notificação do modelo");
        if (tabuleiroGrafico != null) {
            tabuleiroGrafico.atualizar();
        }
    }
    
    /**
     * Atualiza o tabuleiro gráfico
     */
    public void atualizarTabuleiro() {
        if (tabuleiroGrafico != null) {
            tabuleiroGrafico.atualizar();
        }
    }
    
    /**
     * Destaca o rei em xeque
     */
    public void destacarReiEmXeque(int linha, int coluna) {
        if (tabuleiroGrafico != null) {
            tabuleiroGrafico.destacarReiEmXeque(linha, coluna);
        }
    }
    
    /**
     * Limpa o destaque de xeque
     */
    public void limparXeque() {
        if (tabuleiroGrafico != null) {
            tabuleiroGrafico.limparXeque();
        }
    }
    
    /**
     * Seleciona uma casa no tabuleiro
     */
    public void selecionarCasa(int linha, int coluna) {
        if (tabuleiroGrafico != null) {
            tabuleiroGrafico.selecionarCasa(linha, coluna);
        }
    }
    
    /**
     * Mostra os movimentos possíveis
     */
    public void mostrarMovimentosPossiveis(java.util.List<int[]> movimentos) {
        if (tabuleiroGrafico != null) {
            tabuleiroGrafico.mostrarMovimentosPossiveis(movimentos);
        }
    }
    
    /**
     * Limpa a seleção do tabuleiro
     */
    public void limparSelecao() {
        if (tabuleiroGrafico != null) {
            tabuleiroGrafico.limparSelecao();
        }
    }
    
    /**
     * Mostra o menu de promoção de peão
     */
    public void mostrarPromocaoPeao(int linha, int coluna) {
        if (tabuleiroGrafico != null) {
            tabuleiroGrafico.mostrarPromocaoPeao(linha, coluna);
        }
    }
    
    /**
     * Mostra mensagem de fim de jogo
     */
    public void mostrarFimDeJogo(String mensagem) {
        JOptionPane.showMessageDialog(janelaPrincipal, mensagem, 
            "Fim de Jogo", JOptionPane.INFORMATION_MESSAGE);
        janelaPrincipal.mostrarTelaInicial();
    }
    
    /**
     * Mostra o tabuleiro
     */
    public void mostrarTabuleiro() {
        janelaPrincipal.mostrarTabuleiro();
    }
    
    /**
     * Retorna à tela inicial
     */
    public void mostrarTelaInicial() {
        janelaPrincipal.mostrarTelaInicial();
    }
    
    /**
     * Mostra diálogo de salvamento
     */
    public void mostrarDialogoSalvar() {
        // Delegado ao controlador
    }
    
    /**
     * Mostra mensagem de informação
     */
    public void mostrarMensagem(String mensagem, String titulo) {
        JOptionPane.showMessageDialog(janelaPrincipal, mensagem, 
            titulo, JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Mostra diálogo de confirmação
     */
    public int mostrarConfirmacao(String mensagem, String titulo) {
        return JOptionPane.showConfirmDialog(janelaPrincipal,
            mensagem, titulo, JOptionPane.YES_NO_OPTION);
    }
}