package view;

import javax.swing.*;
import java.awt.*;
import model.Cor;
import util.ObservadorIF;
import util.ObservadoIF;
import controller.ControladorJogo;

/**
 * Painel lateral que mostra informações da partida
 * como jogador atual, histórico e status
 */
public class PainelInformacoes extends JPanel implements ObservadorIF {
    private static final long serialVersionUID = 1L;
    
    private JLabel lblJogadorAtual;
    private JTextArea txtHistorico;
    private JLabel lblStatus;
    private JLabel lblNumeroJogada;
    private ControladorJogo controlador;
    
    public PainelInformacoes(ControladorJogo controlador) {
        this.controlador = controlador;
        setPreferredSize(new Dimension(250, 640));
        setBackground(new Color(245, 245, 245));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        setLayout(new BorderLayout());
        
        // Painel superior com informações do jogo
        JPanel painelSuperior = criarPainelSuperior();
        add(painelSuperior, BorderLayout.NORTH);
        
        // Área central com histórico
        JPanel painelHistorico = criarPainelHistorico();
        add(painelHistorico, BorderLayout.CENTER);
        
        // Painel inferior com botões
        JPanel painelBotoes = criarPainelBotoes();
        add(painelBotoes, BorderLayout.SOUTH);
    }
    
    private JPanel criarPainelSuperior() {
        JPanel painel = new JPanel(new GridLayout(3, 1, 5, 5));
        painel.setOpaque(false);
        
        // Jogador atual
        lblJogadorAtual = new JLabel("Vez: Brancas", SwingConstants.CENTER);
        lblJogadorAtual.setFont(new Font("Arial", Font.BOLD, 16));
        lblJogadorAtual.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.BLACK, 2),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        
        // Número da jogada
        lblNumeroJogada = new JLabel("Jogada: 1", SwingConstants.CENTER);
        lblNumeroJogada.setFont(new Font("Arial", Font.PLAIN, 14));
        
        // Status (xeque, xeque-mate, etc)
        lblStatus = new JLabel(" ", SwingConstants.CENTER);
        lblStatus.setFont(new Font("Arial", Font.BOLD, 14));
        lblStatus.setForeground(Color.RED);
        
        painel.add(lblJogadorAtual);
        painel.add(lblNumeroJogada);
        painel.add(lblStatus);
        
        return painel;
    }
    
    private JPanel criarPainelHistorico() {
        JPanel painel = new JPanel(new BorderLayout());
        painel.setOpaque(false);
        painel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Color.GRAY),
            "Histórico de Jogadas"
        ));
        
        txtHistorico = new JTextArea();
        txtHistorico.setEditable(false);
        txtHistorico.setFont(new Font("Courier New", Font.PLAIN, 12));
        txtHistorico.setBackground(Color.WHITE);
        
        JScrollPane scrollPane = new JScrollPane(txtHistorico);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        
        painel.add(scrollPane, BorderLayout.CENTER);
        
        return painel;
    }
    
    private JPanel criarPainelBotoes() {
        JPanel painel = new JPanel(new GridLayout(2, 1, 5, 5));
        painel.setOpaque(false);
        
        JButton btnNovaPartida = new JButton("Nova Partida");
        btnNovaPartida.addActionListener(e -> {
            if (controlador != null) {
                controlador.requestNewGame();
            }
        });
        
        JButton btnSalvar = new JButton("Salvar Partida");
        btnSalvar.addActionListener(e -> {
            if (controlador != null) {
                controlador.salvarPartida();
            }
        });
        
        painel.add(btnNovaPartida);
        painel.add(btnSalvar);
        
        return painel;
    }
    
    @Override
    public void notify(ObservadoIF o) {
        System.out.println("[DEBUG PainelInformacoes] Recebeu notificação do modelo");
        atualizarInformacoes();
    }
    
    public void atualizarInformacoes() {
        if (controlador == null) return;
        
        // Atualizar jogador atual
        Cor jogadorAtual = controlador.getJogadorAtual();
        if (jogadorAtual != null) {
            String jogador = jogadorAtual == Cor.BRANCO ? "Brancas" : "Pretas";
            lblJogadorAtual.setText("Vez: " + jogador);
            lblJogadorAtual.setBackground(jogadorAtual == Cor.BRANCO ? Color.WHITE : Color.GRAY);
            lblJogadorAtual.setOpaque(true);
        }
        
        // Atualizar número da jogada
        int numeroJogada = controlador.getNumeroJogada();
        lblNumeroJogada.setText("Jogada: " + numeroJogada);
        
        // Atualizar status
        String status = controlador.getStatusJogo();
        lblStatus.setText(status != null ? status : " ");
        
        // Atualizar histórico
        String historico = controlador.getHistoricoPGN();
        if (historico != null && !historico.isEmpty()) {
            txtHistorico.setText(formatarHistorico(historico));
            // Auto-scroll para o final
            txtHistorico.setCaretPosition(txtHistorico.getDocument().getLength());
        }
    }
    
    private String formatarHistorico(String pgn) {
        // Formatar PGN para melhor visualização
        StringBuilder formatted = new StringBuilder();
        String[] jogadas = pgn.split(" ");
        
        for (int i = 0; i < jogadas.length; i++) {
            formatted.append(jogadas[i]).append(" ");
            // Quebrar linha após jogada das pretas
            if (i % 3 == 2) {
                formatted.append("\n");
            }
        }
        
        return formatted.toString();
    }
}