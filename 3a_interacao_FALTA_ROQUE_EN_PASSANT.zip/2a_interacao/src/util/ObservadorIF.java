package util;


public interface ObservadorIF {
    /**
     * Método chamado quando o Observado notifica mudanças
     * @param o Objeto observado que sofreu mudança
     */
    void notify(ObservadoIF o);
}