package util;

/**
 * Interface ObservadoIF do padrão Observer
 * Conforme especificado nas transparências do Capítulo 17
 */
public interface ObservadoIF {
    /**
     * Registra um observador
     * @param o Observador a ser registrado
     */
    void add(ObservadorIF o);
    
    /**
     * Remove um observador
     * @param o Observador a ser removido
     */
    void remove(ObservadorIF o);
    
    /**
     * Obtém dados do observado
     * @param i índice do dado a ser obtido
     * @return valor do dado solicitado
     */
    int get(int i);
}